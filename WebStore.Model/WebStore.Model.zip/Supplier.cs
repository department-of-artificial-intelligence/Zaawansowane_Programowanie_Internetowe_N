namespace WebStore.Model
{
    public class Supplier
    {
        public List<Product> Products { get; set; }
    }
}
