namespace WebStore.Model
{
    public class StationaryStoreEmployee
    {
        public string EmployeeName { get; set; }
        public string Position { get; set; }
    }
}
